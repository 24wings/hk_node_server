
export enum MemberType {
    SUPPLIER = 1,
    AGENT,
    CONSUMER,
}

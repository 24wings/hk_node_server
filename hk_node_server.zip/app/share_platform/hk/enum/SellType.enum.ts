
export enum SellTypeEnum {
    /**整团*/
    ALL_SEAT = 1,
    /** 余位*/
    REST_SEAT,
    /**尾单*/
    TAIL_SEAT
}

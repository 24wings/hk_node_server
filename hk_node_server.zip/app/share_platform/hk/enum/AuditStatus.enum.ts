export enum AuditStatusEnum {
    submitted = "submitted",
    approved = "approved",
    expired = "expired"
}
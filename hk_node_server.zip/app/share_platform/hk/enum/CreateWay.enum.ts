export enum CreateWay {
    /**WEB*/
    WEB = "WEB",
    /**APP*/
    APP = "APP"
}

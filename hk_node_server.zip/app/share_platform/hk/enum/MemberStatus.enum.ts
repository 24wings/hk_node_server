export enum MemberStatusEnum {
    submitted = "submitted",
    approved = "approved",
    expired = "expired"

}
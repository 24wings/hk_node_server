
/**产品目标群体*/
export enum ProductTargetEnum {
    /**消费者*/
    C = "C",
    /**代理商*/
    B = "B",
    /**特定代理商*/
    SPEC = "SPEC"
}

export enum OrderRefoundStatusEnum {
    unsubmitted = "unsubmitted",
    submitted = "submitted",
    approved = "approved",
    ajected = "ajected",
    buyer_confirmed = "buyer_confirmed",
    finished = "finished",
    canceled = "canceled"

}
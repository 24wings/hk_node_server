
/**产品类型*/
export enum ProductTypeEnum {
    /**包机*/
    TOTAL = "TOTAL",
    /**切位*/
    CUT_PART = "CUT_PART"
}

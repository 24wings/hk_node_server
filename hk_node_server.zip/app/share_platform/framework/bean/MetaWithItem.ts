import { MetaObject } from '../entity/rbac/MetaObject';

export class MetaWithItem {
    metaObject: MetaObject;
    dataItem: any;
}


export class UserMapper {
    name: string
}
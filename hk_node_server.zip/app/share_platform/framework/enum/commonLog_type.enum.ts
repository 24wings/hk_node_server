export enum CommonLogTypeEnum {
    MemberAuthSuccess = "member_auth_success",
    MemberAuthFail = "member_auth_fail"
}
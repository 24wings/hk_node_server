export enum UserStatus {
    Active = "active",
    Disabled = "disabled",
    Frozen = "frozen"
}
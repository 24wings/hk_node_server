export enum SMSTypeEnum {
    Signup = "singup_authcode",
    Msg = "msg",
    AppForgotPasswordAuthcode = "app_forgot_password_authcode"
    // ....
}
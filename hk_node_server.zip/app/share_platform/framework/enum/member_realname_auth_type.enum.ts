export enum MemberRealnameAuthType {
    Person = "person",
    Company = "company"
}

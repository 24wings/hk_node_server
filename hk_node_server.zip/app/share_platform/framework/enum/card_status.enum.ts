export enum CardStatusEnum {
    Active = "active",
    Frozen = "frozen",
    Disabled = "disabled"
}
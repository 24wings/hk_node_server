export enum MemberRealnameAuthStatusEnum {
    Processing = "processing",
    Pass = "pass",
    Fali = "fail"
}
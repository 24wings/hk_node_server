/** 产品计重方式 */
export enum ProductValuationTypeEnum {
    Piece = "piece",
    Weight = "weight"
}
export enum MemberLevelEnum {
    Normal = "normal"
}
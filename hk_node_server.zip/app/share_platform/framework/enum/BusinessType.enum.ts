export enum BussinessTypeEnum {
    /** 充值 */
    RECHARGE = "RECHARGE",
    /** 提现 */
    WITHDRAW = "WITHDRAW"
}

export enum UserStatusEnum {
    Active = "Active",
    Eanble = "Enable"
}
export enum MenuTypeEnum {
    Market,
    None,

    Dev,
} 
export enum AccountOwnerType {
    MemberAccount = "member_account",
    MarketAccount = "market_account"
}
export enum MarketStatusEnum {
    Active = "Active",
    Disabled = "Disabled"
}
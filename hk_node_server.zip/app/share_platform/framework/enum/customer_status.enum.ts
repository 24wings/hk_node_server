export enum CustomerStatusEnumType {
    Active = "active",
    Disabled = "disabled",
    Frozen = "frozen"
}
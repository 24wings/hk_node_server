export enum FeeListStatusEnum {
    Active = "active"
}
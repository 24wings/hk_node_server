export enum InviteLogStatusEnum {
    Active = "active",
    Agree = "agree",
    Refuse = "refuse"
}
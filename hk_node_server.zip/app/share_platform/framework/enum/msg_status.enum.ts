export enum MsgStatusEnum {
    Unchecked = "unchecked",
    Checked = "checked"
}
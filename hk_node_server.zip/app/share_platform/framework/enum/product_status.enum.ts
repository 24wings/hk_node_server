export enum ProductStatusEnum {
    /**上架 */
    Online = "online",
    /** 下架*/
    Offline = "offline"
}
export enum MsgContentTypeEnum {
    AccountChange = "account_change",
    Inviteinfo = "invite_info",
    CashRepaymentNotice = "cash_repayment_notice",
    CashRepaymentConfirm = "cash_repayment_confirm",
    ToBePay = "to_be_pay",
    ActorChange = "actor_change"
}


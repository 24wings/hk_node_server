export enum FeelistStatusEnum {
    Active = "active",
    Finish = "finish"
}
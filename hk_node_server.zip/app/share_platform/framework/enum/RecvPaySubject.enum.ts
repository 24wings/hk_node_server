export enum RecvPaySubjectEnum {
    /** 货品交易 */
    Order = 1,

}
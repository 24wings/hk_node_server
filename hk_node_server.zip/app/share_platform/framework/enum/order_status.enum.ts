export enum OrderStatusEnum {
    Active = "active",
    Disabled = "disabled",
    Confirm = "confirm",
    Hangup = "hangup",
    Upload = "upload"
}
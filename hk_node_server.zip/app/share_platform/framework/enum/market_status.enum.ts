export enum MarketStatusEnum {
    Active = "active",
    Disabled = "disabled"
}
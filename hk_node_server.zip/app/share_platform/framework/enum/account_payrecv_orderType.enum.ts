export enum AccountPayRecvOrderType {
    /**订单类型 */
    OrderType = "order_type"
}
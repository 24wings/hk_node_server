
export let api = {
    // home: '/home',
    /**
     * post   body:MeberRealnameAuth
     */
    memberRealnameAuthCreate: "/customer/memberRealnameAuth/create",
    // get  ? memberId&mktId
    memberDetail: '/customer/member/detail',
    // getMeberS

};


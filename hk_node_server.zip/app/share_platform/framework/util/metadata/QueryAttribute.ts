
export class QueryAttribute {
    key: string;
    value: string;
    type: string;
    alias: string;
}
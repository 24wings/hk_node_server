export class Res {
    constructor(public status: number, public data: any, public ok: boolean, public msg: string) { }
}
function sayHello(str: string) {
    console.log(arguments)
    console.log(str);
}

// sayHello("hello");


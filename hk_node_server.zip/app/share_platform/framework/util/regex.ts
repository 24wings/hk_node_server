export let regxep = {
    phone: /^1[0-9]\d{9}$/
}

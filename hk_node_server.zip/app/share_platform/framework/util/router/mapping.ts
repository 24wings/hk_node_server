import { bp } from 'egg-blueprint';

export const Post = bp.post;
export const Get = bp.get;
export class MessageUtil {

}
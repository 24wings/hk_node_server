export enum MemberStatusEnum {
    Frozen = "Frozen",
    Disabled = "Disabled",
    ENABLE = "ENABLE"
}  
export enum CustCardStatusEnum {
    ENABLE, DISABLE, CANCEL, ACTIVE, FROZEN
}
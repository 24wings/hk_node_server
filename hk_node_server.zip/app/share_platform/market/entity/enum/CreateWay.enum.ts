export enum CreateWayEnum {
    WEB = "WEB",
    APP = "APP",
    POS = "POS"
}  
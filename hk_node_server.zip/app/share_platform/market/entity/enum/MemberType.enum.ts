
export enum MemberTypeEnum {
    PERSONAL = "PERSONAL",//个人
    COMPANY = "COMPANY"//企业
}

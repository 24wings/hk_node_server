import { RecvPaySubject } from '../common/RecvPaySubject';

export const systemSubjects: RecvPaySubject[] = [{ subjectId: 1, mktId: 0, subjectName: "交易货款", subjectCode: "TRANS", parentId: 0 } as any]
export enum IOEnum {
    IN = 1,
    OUT = -1
}
export enum PriceWayEnum {
    WEIGHT = "WEIGHT", PIECE = "PIECE"
}
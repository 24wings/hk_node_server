export enum QcodeBizTypeEnum {
    /** (0,"成员信息"),*/
    MEMBER = "MEMBER",
    /**(1,"交易支付") */
    TRANS_PAY = "TRANS_PAY",
    /** (2,"转账收款");*/
    TRANS_ACC = "TRANS_ACC"

}

export enum PriceUnitEnum {
    KG = "KG", JIN = "JIN"
}

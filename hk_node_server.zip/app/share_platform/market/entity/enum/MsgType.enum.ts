export enum MsgTypeEnum {
    Notify = 1, Message, Task
}

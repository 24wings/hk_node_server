export enum OrderTypeEnum {
    TRANS = "TRANS", RENTS = "RENTS"
}
export enum FeeListStatusEnum {
    Active = "Active",
    Process = "Process",
    Finish = "Finish"
}
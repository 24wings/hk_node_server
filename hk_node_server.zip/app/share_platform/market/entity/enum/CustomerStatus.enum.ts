export enum CustomerStatusEnum {
    Frozen = "Frozen",
    Disabled = "Disabled",
    Active = "Active"
}
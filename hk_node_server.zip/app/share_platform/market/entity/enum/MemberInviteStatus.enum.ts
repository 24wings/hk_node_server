
export enum MemberInviteStatusEnum {
    Active = "Active", Del = "Del", Agree = "Agree", Refuse = "Refuse"
}
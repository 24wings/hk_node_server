export enum RoleType {
    GroupCompany = 1,
    Market
}

export enum EmployeeType {
    GroupCompany = 1,
    Market = 2
}
export enum MarketStatus {
    Disabled = 0,
    Active
}
export enum EmployeeStatus {
    Disabled = 0,
    Active = 1
}
export let regex = {
}
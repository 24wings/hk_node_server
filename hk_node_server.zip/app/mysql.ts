// import mysql = require('mysql2');

// create the connection to database
// export const connection = mysql.createConnection({
//     host: '47.95.203.108',
//     user: 'root',
//     password: "!*@&#%$N1Nadmindb2017",
//     database: 'org_test',
// });

// This file was auto created by egg-ts-helper
// Do not modify this file!!!!!!!!!

import 'egg-view-nunjucks';
import 'egg-sequelize';
import 'egg-oss';
import 'egg-static';
import 'egg-mongoose';
import 'egg-mysql';
import 'egg-cors';